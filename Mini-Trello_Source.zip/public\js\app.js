const API_BASE = '/api/tasks';

const STATUS_ORDER = ['todo', 'in_progress', 'done'];

const els = {
  board: document.getElementById('board'),
  columns: {
    todo: document.getElementById('col-todo'),
    in_progress: document.getElementById('col-in_progress'),
    done: document.getElementById('col-done'),
  },
  openCreateModal: document.getElementById('open-create-modal'),
  modalOverlay: document.getElementById('modal-overlay'),
  modalTitle: document.getElementById('modal-title'),
  taskForm: document.getElementById('task-form'),
  taskTitle: document.getElementById('task-title'),
  taskDescription: document.getElementById('task-description'),
  modalError: document.getElementById('modal-error'),
  cancelCreate: document.getElementById('cancel-create'),
};

let tasks = [];
let editingId = null;

async function api(url, options) {
  let res;
  try {
    res = await fetch(url, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
  } catch (err) {
    throw new Error(
      'Cannot reach server. Open the app at http://localhost:3000 (do not double-click index.html).'
    );
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || 'Request failed');
  }
  return res.status === 204 ? null : res.json();
}

async function loadTasks() {
  tasks = await api(API_BASE);
  render();
}

function cardTemplate(task) {
  const idx = STATUS_ORDER.indexOf(task.status);
  const hasPrev = idx > 0;
  const hasNext = idx < STATUS_ORDER.length - 1;

  return `
    <div class="card" data-id="${task.id}">
      <div class="card__title">${escapeHtml(task.title)}</div>
      ${
        task.description
          ? `<div class="card__description">${escapeHtml(task.description)}</div>`
          : ''
      }
      <div class="card__actions">
        <button class="btn btn--sm btn--ghost" data-action="prev" ${hasPrev ? '' : 'disabled'}>← Prev</button>
        <button class="btn btn--sm btn--primary" data-action="next" ${hasNext ? '' : 'disabled'}>Next →</button>
        <span class="spacer"></span>
        <button class="btn btn--sm btn--danger" data-action="delete" title="Delete task">🗑 Delete</button>
      </div>
    </div>
  `;
}

function render() {
  STATUS_ORDER.forEach((status) => {
    const container = els.columns[status];
    const columnTasks = tasks.filter((t) => t.status === status);
    if (columnTasks.length === 0) {
      container.innerHTML = `<div class="empty-state">No tasks here yet</div>`;
    } else {
      container.innerHTML = columnTasks.map(cardTemplate).join('');
    }
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function openModal() {
  editingId = null;
  els.modalTitle.textContent = 'Create New Task';
  els.taskForm.reset();
  els.modalError.hidden = true;
  els.modalOverlay.hidden = false;
  els.taskTitle.focus();
}

function closeModal() {
  els.modalOverlay.hidden = true;
}

async function handleSubmit(e) {
  e.preventDefault();
  const title = els.taskTitle.value.trim();
  const description = els.taskDescription.value.trim();

  if (!title) {
    showError('Title is required.');
    return;
  }

  hideError();
  try {
    if (editingId) {
      await api(`${API_BASE}/${editingId}`, {
        method: 'PATCH',
        body: JSON.stringify({ title, description }),
      });
    } else {
      await api(API_BASE, {
        method: 'POST',
        body: JSON.stringify({ title, description }),
      });
    }
    closeModal();
    await loadTasks();
  } catch (err) {
    showError(err.message);
  }
}

function showError(message) {
  els.modalError.textContent = message;
  els.modalError.hidden = false;
}

function hideError() {
  els.modalError.hidden = true;
}

async function moveTask(id, direction) {
  const task = tasks.find((t) => t.id === String(id));
  if (!task) return;
  const idx = STATUS_ORDER.indexOf(task.status);
  const nextIdx = idx + direction;
  if (nextIdx < 0 || nextIdx >= STATUS_ORDER.length) return;

  try {
    await api(`${API_BASE}/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: STATUS_ORDER[nextIdx] }),
    });
    await loadTasks();
  } catch (err) {
    alert(err.message);
  }
}

async function deleteTask(id) {
  if (!confirm('Are you sure you want to delete this task?')) return;
  try {
    await api(`${API_BASE}/${id}`, { method: 'DELETE' });
    await loadTasks();
  } catch (err) {
    alert(err.message);
  }
}

els.board.addEventListener('click', async (event) => {
  const btn = event.target.closest('button[data-action]');
  if (!btn) return;
  const card = btn.closest('.card');
  const id = card && card.getAttribute('data-id');
  if (!id) return;

  const action = btn.getAttribute('data-action');
  if (action === 'prev') await moveTask(id, -1);
  else if (action === 'next') await moveTask(id, 1);
  else if (action === 'delete') await deleteTask(id);
});

els.openCreateModal.addEventListener('click', openModal);
els.cancelCreate.addEventListener('click', closeModal);
els.modalOverlay.addEventListener('click', (e) => {
  if (e.target === els.modalOverlay) closeModal();
});
els.taskForm.addEventListener('submit', handleSubmit);

loadTasks();
