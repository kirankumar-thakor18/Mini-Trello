# Mini-Trello Kanban Board

A simple single-page Kanban board where users can create tasks and move them
between three columns: **To Do**, **In Progress**, and **Done**.

This project demonstrates Frontend development (HTML/CSS/JS), Backend API
creation (Node.js + Express), Database management (SQLite), and Agile/Scrum
methodology.

## Tech Stack

- **Frontend:** HTML, CSS, Vanilla JavaScript
- **Backend:** Node.js + Express
- **Database:** SQLite (via Node's built-in `node:sqlite` — no extra install needed)
- **Architecture:** RESTful API

## Project Structure

```
mini-trello/
├── package.json
├── README.md
├── server/
│   ├── server.js      # Express server + REST routes
│   └── db.js          # SQLite database setup & schema
├── public/
│   ├── index.html     # Single-page UI
│   ├── css/styles.css
│   └── js/app.js      # Frontend logic (fetch API)
└── data/              # SQLite database file (created on first run)
```

## Features

- Create a new task (Title required, Description optional) -> added to **To Do**
- View all tasks grouped by status in 3 columns
- Move a task forward/backward (To Do → In Progress → Done) with **Next/Prev**
- Delete a task with confirmation
- Changes persist in the database and reflect immediately in the UI

## REST API Endpoints

| Method | Endpoint              | Description                        |
| ------ | --------------------- | ---------------------------------- |
| GET    | `/api/tasks`          | Fetch all tasks                    |
| POST   | `/api/tasks`          | Create a new task (status = todo)  |
| PATCH  | `/api/tasks/:id`      | Update status/title/description    |
| PUT    | `/api/tasks/:id`      | Replace task fields                |
| DELETE | `/api/tasks/:id`      | Delete a task                      |

### Sample Task Object

```json
{
  "id": "101",
  "title": "Design Database Schema",
  "description": "Create ER diagram for the task and user tables.",
  "status": "in_progress"
}
```

### Sample Request / Response

**POST /api/tasks**

Request body:
```json
{
  "title": "Set up Express server",
  "description": "Create basic routes for the API."
}
```

Response (201):
```json
{
  "id": "1",
  "title": "Set up Express server",
  "description": "Create basic routes for the API.",
  "status": "todo"
}
```

**PATCH /api/tasks/1**

Request body:
```json
{ "status": "in_progress" }
```

Response (200):
```json
{
  "id": "1",
  "title": "Set up Express server",
  "description": "Create basic routes for the API.",
  "status": "in_progress"
}
```

## How to Run Locally

1. **Prerequisites:** Node.js **v22.5 or later** (uses the built-in `node:sqlite`
   module) installed on your machine.

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the server:**
   ```bash
   npm start
   ```

4. Open your browser and visit:
   ```
   http://localhost:3000
   ```

> The SQLite database is created automatically at `data/mini-trello.db` on the
> first run, so no separate database setup is required.

## Testing the API with Postman

- `GET http://localhost:3000/api/tasks` — list all tasks
- `POST http://localhost:3000/api/tasks` with JSON body `{ "title": "..." }`
- `PATCH http://localhost:3000/api/tasks/1` with `{ "status": "done" }`
- `DELETE http://localhost:3000/api/tasks/1`

## Agile Execution Summary

**Sprint 1 — Foundation & Setup**
- Database schema designed (`tasks` table: id, title, description, status).
- Backend CRUD routes for **Create** and **Read** created.
- Static HTML/CSS 3-column layout built.

**Sprint 2 — Integration & Delivery**
- **Update** and **Delete** routes completed (PATCH/PUT/DELETE).
- Frontend connected to backend using the `fetch` API.
- Card movement/creation/deletion fully wired to API and reflected live in UI.
