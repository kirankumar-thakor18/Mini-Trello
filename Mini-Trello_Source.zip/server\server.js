const express = require('express');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

const VALID_STATUSES = ['todo', 'in_progress', 'done'];

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

const rowsToTasks = (rows) =>
  rows.map((r) => ({
    id: String(r.id),
    title: r.title,
    description: r.description,
    status: r.status,
  }));

app.get('/api/tasks', (req, res) => {
  const rows = db.prepare('SELECT * FROM tasks ORDER BY id').all();
  res.json(rowsToTasks(rows));
});

app.post('/api/tasks', (req, res) => {
  const { title, description = '' } = req.body || {};

  if (!title || !String(title).trim()) {
    return res.status(400).json({ error: 'Title is required' });
  }

  const result = db
    .prepare('INSERT INTO tasks (title, description, status) VALUES (?, ?, ?)')
    .run(String(title).trim(), String(description).trim(), 'todo');

  const row = db
    .prepare('SELECT * FROM tasks WHERE id = ?')
    .get(result.lastInsertRowid);

  res.status(201).json(rowsToTasks([row])[0]);
});

app.patch('/api/tasks/:id', (req, res) => {
  const id = Number(req.params.id);
  const { status, title, description } = req.body || {};

  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  if (!task) {
    return res.status(404).json({ error: 'Task not found' });
  }

  const newStatus = status !== undefined ? String(status) : task.status;
  if (!VALID_STATUSES.includes(newStatus)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  const newTitle =
    title !== undefined && String(title).trim() ? String(title).trim() : task.title;
  const newDescription =
    description !== undefined ? String(description).trim() : task.description;

  db.prepare(
    'UPDATE tasks SET status = ?, title = ?, description = ? WHERE id = ?'
  ).run(newStatus, newTitle, newDescription, id);

  const updated = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  res.json(rowsToTasks([updated])[0]);
});

app.put('/api/tasks/:id', (req, res) => {
  const id = Number(req.params.id);
  const { status, title, description } = req.body || {};

  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  if (!task) {
    return res.status(404).json({ error: 'Task not found' });
  }

  const newStatus = status !== undefined ? String(status) : task.status;
  if (!VALID_STATUSES.includes(newStatus)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  const newTitle =
    title !== undefined && String(title).trim() ? String(title).trim() : task.title;
  const newDescription =
    description !== undefined ? String(description).trim() : task.description;

  db.prepare(
    'UPDATE tasks SET status = ?, title = ?, description = ? WHERE id = ?'
  ).run(newStatus, newTitle, newDescription, id);

  const updated = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  res.json(rowsToTasks([updated])[0]);
});

app.delete('/api/tasks/:id', (req, res) => {
  const id = Number(req.params.id);
  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(id);
  if (!task) {
    return res.status(404).json({ error: 'Task not found' });
  }
  db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
  res.status(204).end();
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Mini-Trello server running at http://localhost:${PORT}`);
});
